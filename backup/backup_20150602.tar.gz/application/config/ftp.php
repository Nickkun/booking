<?php

$config['hostname'] = '115.68.16.59';
$config['username'] = 'booking';
$config['password'] = 'qnzld';
$config['port'] = '35021';
$config['passive'] = TRUE;
$config['debug'] = TRUE;


?>