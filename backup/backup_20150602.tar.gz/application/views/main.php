<section class="container">
	<ul class="nav nav-pills nav-stacked">
		<li><a href="/booking">목록</a></li>
		<li><a href="/mypage">마이페이지</a></li>
	</ul>
</section>