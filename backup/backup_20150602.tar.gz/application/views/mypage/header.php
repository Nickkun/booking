<section class="container">
	<nav>
		<ul class="nav nav-pills nav-justified">
			<li role="presentation" class="<?php if ($view == '/mypage/booking_list') echo 'active' ?>"><a href="/mypage">내 예약현황</a></li>
			<li role="presentation" class="<?php if ($view == '/mypage/item_list') echo 'active' ?>"><a href="/mypage/item_list">내 개설현황</a></li>
			<li role="presentation" class="<?php if ($view == '/mypage/password_change') echo 'active' ?>"><a href="/mypage/password_change">비밀번호 변경</a></li>
			<li role="presentation" class="<?php if ($view == '/mypage/myinfo') echo 'active' ?>"><a href="/mypage/myinfo">개인정보관리</a></li>
		</ul>
	</nav>

	