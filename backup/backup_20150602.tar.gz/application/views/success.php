<div class="container">
	<h4>성공</h4>
	<div class="panel panel-success">
		<div class="panel-heading"><?php echo $result ?></div>
		<div class="panel-body"><?php echo $msg ?></div>
	</div>
	<div class="pull-right">
		<a href="<?php echo $redirect ?>" class="btn btn-default" role="button">돌아가기</a>
	</div>
</div>