###################
Booking module with Codeigniter v3.0
###################

Booking System with Codeigniter v3.0

*******************
Release Information
*******************



**************************
Changelog and New Features
**************************
v0.1
- initialize upload

*******************
Server Requirements
*******************

PHP version 5.4 or newer is recommended.

It should work on 5.2.4 as well, but we strongly advise you NOT to run
such old versions of PHP, because of potential security and performance
issues, as well as missing features.

*********
License
*********

Not yet
We are develope now
